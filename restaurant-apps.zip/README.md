# LAPER APPS
Submission ke-2 Dicoding : Menjadi Front-End Web Developer Expert

![alt text](https://github.com/dazelpro/katalog-restoran/blob/master/src/public/mockup.webp)
